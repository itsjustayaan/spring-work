package com.training.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

    private String getUsername() {
        String principal = SecurityContextHolder.getContext().getAuthentication().getName();
        if(principal == "anonymousUser") {
        	principal = "Guest";
        }
        return principal;
    }

    @RequestMapping("")
    public String index(Model model) {
        String username = getUsername();
        model.addAttribute("username", username);
        return "index";
    }

    @RequestMapping("/addProduct")
    public String addProduct(Model model) {
        String username = getUsername();
        model.addAttribute("username", username);
        return "addProduct";
    }

    @RequestMapping("/updateProduct")
    public String updateProduct(Model model) {
        String username = getUsername();
        model.addAttribute("username", username);
        return "updateProduct";
    }

    @RequestMapping("/viewAllProducts")
    public ModelAndView viewAllProducts() {
        ModelAndView view = new ModelAndView();
        String username = getUsername();
        view.addObject("username", username);
        view.setViewName("viewAllProducts"); // Set the view name
        return view;
    }

    @GetMapping("/calculateEMI")
    public String calculateEMI(Model model, @RequestParam(required = false) Double principle, @RequestParam(required = false) Double interest, @RequestParam(required = false) Integer duration, @RequestParam(required = false) String error) {
        String username = getUsername();
        model.addAttribute("username", username);

        if (principle == null || interest == null || duration == null || principle <= 0 || interest <= 0 || duration <= 0) {
            model.addAttribute("errorMsg", "Please Fill Out All Fields with valid values!");
        } else {
            double emi = (principle * interest) / (100 * duration);
            model.addAttribute("errorMsg", String.format("%.2f", emi));
        }
        model.addAttribute("principle", principle);
        model.addAttribute("interest", interest);
        model.addAttribute("duration", duration);
        return "calculateEMI";
    }

    @RequestMapping("/denied")
    public String denied(Model model) {
        String username = getUsername();
        model.addAttribute("username", username);
        return "denied";
    }
}
